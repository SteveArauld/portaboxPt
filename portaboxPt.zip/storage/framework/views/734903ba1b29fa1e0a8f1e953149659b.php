<?php $__env->startSection('title', __('terms.page_title')); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('body_class', 'wp-singular page-template-default page page-id-12301 wp-theme-merto theme-merto woocommerce-js wide header-v1 product-label-rectangle product-hover-style-v2 product-border-radius vertical-menu-fixed ts_desktop elementor-default elementor-kit-10348 e--ua-blink e--ua-chrome e--ua-webkit cht-in-desktop cht-landscape'); ?>

<?php $__env->startSection('content'); ?>
    <div id="main" class="wrapper ">
        <div class="breadcrumb-title-wrapper breadcrumb-v3">
            <div class="container">
                <div class="breadcrumb-title">
                    <h1 class="heading-title page-title entry-title "><?php echo e(__('terms.page_title')); ?></h1>
                    <div class="ts-breadcrumbs breadcrumbs">
                        <div class="breadcrumbs-container">
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('terms.breadcrumb_home')); ?></a>
                            <span class="brn_arrow">/</span>
                            <span class="current"><?php echo e(__('terms.breadcrumb_current')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-container show_breadcrumb_v3 no-sidebar">

            <div id="main-content">
                <div id="primary" class="site-content">
                    <article id="post-2" class="post-2 page type-page status-publish hentry">

                        <h2 class="wp-block-heading"><strong><?php echo e(__('terms.title')); ?></strong></h2>

                        <p>
                            <strong><?php echo e(__('terms.company_name')); ?></strong><br>
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(route('home')); ?></a>
                        </p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section1.title')); ?></h2>

                        <p>
                            <?php echo e(__('terms.section1.text1')); ?>

                            <strong><?php echo e(__('terms.company_name')); ?></strong>,
                            <?php echo e(__('terms.section1.text2')); ?>

                        </p>

                        <p><?php echo e(__('terms.section1.text3')); ?></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section2.title')); ?></h2>

                        <p>
                            <strong><?php echo e(__('terms.company_name')); ?></strong><br>
                            <strong><?php echo e(__('terms.section2.legal_address')); ?></strong> <?php echo e(__('terms.address')); ?><br>
                            <strong><?php echo e(__('terms.section2.phone')); ?></strong> <?php echo e(__('terms.phone')); ?><br>
                            <strong><?php echo e(__('terms.section2.email')); ?></strong> <a href="mailto:<?php echo e(__('terms.email')); ?>"><?php echo e(__('terms.email')); ?></a><br>
                            <strong><?php echo e(__('terms.section2.website')); ?></strong> <a href="<?php echo e(route('home')); ?>"><?php echo e(route('home')); ?></a>
                        </p>

                        <p>
                            <strong><?php echo e(__('terms.section2.vat')); ?></strong> <?php echo e(__('terms.vat')); ?><br>
                            <strong><?php echo e(__('terms.section2.european_vat')); ?></strong> <?php echo e(__('terms.european_vat')); ?>

                        </p>

                        <p>
                            <strong><?php echo e(__('terms.section2.activity')); ?></strong> <?php echo e(__('terms.activity')); ?>

                        </p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section3.title')); ?></h2>

                        <p><strong><?php echo e(__('terms.company_name')); ?></strong> <?php echo e(__('terms.section3.text1')); ?></p>

                        <p><?php echo e(__('terms.section3.text2')); ?></p>

                        <p><?php echo e(__('terms.section3.text3')); ?></p>

                        <p><?php echo e(__('terms.section3.text4')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section3.option1')); ?></li>
                            <li><?php echo e(__('terms.section3.option2')); ?></li>
                        </ul>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section4.title')); ?></h2>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section4.subtitle1')); ?></h3>

                        <p><?php echo e(__('terms.section4.text1')); ?></p>

                        <p><strong><?php echo e(__('terms.company_name')); ?></strong> <?php echo e(__('terms.section4.text2')); ?></p>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section4.subtitle2')); ?></h3>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section4.payment1')); ?></li>
                            <li><?php echo e(__('terms.section4.payment2')); ?></li>
                            <li><?php echo e(__('terms.section4.payment3')); ?></li>
                        </ul>

                        <p><?php echo e(__('terms.section4.text3')); ?><br><?php echo e(__('terms.section4.text4')); ?></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section5.title')); ?></h2>

                        <p><?php echo e(__('terms.section5.text1')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section5.confirmation1')); ?></li>
                            <li><?php echo e(__('terms.section5.confirmation2')); ?></li>
                        </ul>

                        <p><strong><?php echo e(__('terms.company_name')); ?></strong> <?php echo e(__('terms.section5.text2')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section5.refusal1')); ?></li>
                            <li><?php echo e(__('terms.section5.refusal2')); ?></li>
                            <li><?php echo e(__('terms.section5.refusal3')); ?></li>
                            <li><?php echo e(__('terms.section5.refusal4')); ?></li>
                            <li><?php echo e(__('terms.section5.refusal5')); ?></li>
                        </ul>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section6.title')); ?></h2>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section6.subtitle1')); ?></h3>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section6.zone1')); ?></li>
                            <li><?php echo e(__('terms.section6.zone2')); ?></li>
                        </ul>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section6.subtitle2')); ?></h3>

                        <p><?php echo e(__('terms.section6.text1')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section6.cost1')); ?></li>
                            <li><?php echo e(__('terms.section6.cost2')); ?></li>
                            <li><?php echo e(__('terms.section6.cost3')); ?></li>
                        </ul>

                        <p><?php echo e(__('terms.section6.text2')); ?></p>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section6.subtitle3')); ?></h3>

                        <p><?php echo e(__('terms.section6.text3')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section6.delay1')); ?></li>
                            <li><?php echo e(__('terms.section6.delay2')); ?></li>
                        </ul>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section6.subtitle4')); ?></h3>

                        <p><?php echo e(__('terms.section6.text4')); ?></p>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section6.subtitle5')); ?></h3>

                        <p><?php echo e(__('terms.section6.text5')); ?></p>

                        <p><?php echo e(__('terms.section6.text6')); ?></p>

                        <p><?php echo e(__('terms.section6.text7')); ?></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section7.title')); ?></h2>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section7.subtitle1')); ?></h3>

                        <p><?php echo e(__('terms.section7.text1')); ?></p>

                        <p><?php echo e(__('terms.section7.text2')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section7.exception1')); ?></li>
                            <li><?php echo e(__('terms.section7.exception2')); ?></li>
                            <li><?php echo e(__('terms.section7.exception3')); ?></li>
                        </ul>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section7.subtitle2')); ?></h3>

                        <p><?php echo e(__('terms.section7.text3')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section7.condition1')); ?></li>
                            <li><?php echo e(__('terms.section7.condition2')); ?></li>
                            <li><?php echo e(__('terms.section7.condition3')); ?></li>
                        </ul>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section7.subtitle3')); ?></h3>

                        <p><?php echo e(__('terms.section7.text4')); ?><br><?php echo e(__('terms.section7.text5')); ?></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section8.title')); ?></h2>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section8.subtitle1')); ?></h3>

                        <p><?php echo e(__('terms.section8.text1')); ?></p>

                        <p><?php echo e(__('terms.section8.text2')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section8.exclusion1')); ?></li>
                            <li><?php echo e(__('terms.section8.exclusion2')); ?></li>
                            <li><?php echo e(__('terms.section8.exclusion3')); ?></li>
                            <li><?php echo e(__('terms.section8.exclusion4')); ?></li>
                        </ul>

                        <h3 class="wp-block-heading"><?php echo e(__('terms.section8.subtitle2')); ?></h3>

                        <p><?php echo e(__('terms.section8.text3')); ?><br><?php echo e(__('terms.section8.text4')); ?></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section9.title')); ?></h2>

                        <p><?php echo e(__('terms.section9.text1')); ?></p>

                        <p>
                            <a href="mailto:<?php echo e(__('terms.email')); ?>"><?php echo e(__('terms.email')); ?></a><br>
                            WhatsApp: <?php echo e(__('terms.phone')); ?><br>
                            <?php echo e(__('terms.section9.hours')); ?> <?php echo e(__('terms.section9.hours_text')); ?>

                        </p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section10.title')); ?></h2>

                        <p><?php echo e(__('terms.section10.text1')); ?><br><strong><?php echo e(__('terms.company_name')); ?></strong> <?php echo e(__('terms.section10.text2')); ?></p>

                        <p><?php echo e(__('terms.section10.text3')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section10.right1')); ?></li>
                            <li><?php echo e(__('terms.section10.right2')); ?></li>
                            <li><?php echo e(__('terms.section10.right3')); ?></li>
                            <li><?php echo e(__('terms.section10.right4')); ?></li>
                            <li><?php echo e(__('terms.section10.right5')); ?></li>
                        </ul>

                        <p><?php echo e(__('terms.section10.text4')); ?> <strong><a href="mailto:<?php echo e(__('terms.email')); ?>"><?php echo e(__('terms.email')); ?></a></strong></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section11.title')); ?></h2>

                        <p><strong><?php echo e(__('terms.company_name')); ?></strong> <?php echo e(__('terms.section11.text1')); ?></p>

                        <ul class="wp-block-list">
                            <li><?php echo e(__('terms.section11.point1')); ?></li>
                            <li><?php echo e(__('terms.section11.point2')); ?></li>
                            <li><?php echo e(__('terms.section11.point3')); ?></li>
                            <li><?php echo e(__('terms.section11.point4')); ?></li>
                            <li><?php echo e(__('terms.section11.point5')); ?></li>
                        </ul>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section12.title')); ?></h2>

                        <p><?php echo e(__('terms.section12.text1')); ?><br><?php echo e(__('terms.section12.text2')); ?><br> <strong><?php echo e(__('terms.city')); ?></strong>.</p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('terms.section13.title')); ?></h2>

                        <p>
                            <strong><?php echo e(__('terms.company_name')); ?></strong><br>
                            <?php echo e(__('terms.address')); ?><br>
                            <a href="mailto:<?php echo e(__('terms.email')); ?>"><?php echo e(__('terms.email')); ?></a><br>
                            <?php echo e(__('terms.phone')); ?><br>
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(route('home')); ?></a>
                        </p>

                        <p>
                            <strong><?php echo e(__('terms.last_update')); ?></strong> <?php echo e(__('terms.date')); ?><br>
                            © <strong><?php echo e(__('terms.company_name')); ?></strong> – <?php echo e(__('terms.copyright')); ?>

                        </p>

                        <figure class="wp-block-image size-full is-resized">
                            <img fetchpriority="high" decoding="async"
                                 width="512" height="512"
                                 src="/assets/uploads/2026/02/cropped-Porto-Contentores-scaled-1.png"
                                 alt="<?php echo e(__('terms.company_name')); ?>" class="wp-image-12724"
                                 style="width:483px;height:auto"
                                 sizes="(max-width: 512px) 100vw, 512px">
                        </figure>

                        <p></p>
                    </article>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/portaboxPt/resources/views/front/legal/terms-conditions.blade.php ENDPATH**/ ?>