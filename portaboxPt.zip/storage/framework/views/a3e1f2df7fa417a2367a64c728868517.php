<?php
    /** @var \App\Models\Article $item */
    $cbImg = $item->images->where('is_primary', true)->first() ?? $item->images->first();
    $cbImgUrl = $cbImg ? $cbImg->image_path : 'https://via.placeholder.com/300x300?text=No+Image';
?>
<div class="pbs-cart-action">
    <button type="button"
            class="pbs-add-to-cart"
            data-add-to-cart
            data-id="<?php echo e($item->id); ?>"
            data-name="<?php echo e($item->name); ?>"
            data-price="<?php echo e($item->price); ?>"
            data-slug="<?php echo e($item->slug); ?>"
            data-sku="<?php echo e($item->sku); ?>"
            data-image="<?php echo e($cbImgUrl); ?>"
            data-url="<?php echo e(route('product.show', $item->slug)); ?>">
         <i class="fas fa-plus"></i>
                        <span class="pbs-add-label"><?php echo e(__('Ajouter au panier')); ?></span>
    </button>
</div>
<?php /**PATH /var/www/html/portaboxPt/resources/views/front/partials/cart-button.blade.php ENDPATH**/ ?>