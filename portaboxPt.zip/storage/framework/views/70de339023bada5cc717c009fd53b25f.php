<?php $__env->startSection('title', __('payment.page_title')); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('body_class', 'wp-singular page-template-default page page-id-12301 wp-theme-merto theme-merto woocommerce-js wide header-v1 product-label-rectangle product-hover-style-v2 product-border-radius vertical-menu-fixed ts_desktop elementor-default elementor-kit-10348 e--ua-blink e--ua-chrome e--ua-webkit cht-in-desktop cht-landscape'); ?>

<?php $__env->startSection('content'); ?>

    <div id="main" class="wrapper ">
        <div class="breadcrumb-title-wrapper breadcrumb-v3">
            <div class="container">
                <div class="breadcrumb-title">
                    <h1 class="heading-title page-title entry-title "><?php echo e(__('payment.page_title')); ?></h1>
                    <div class="ts-breadcrumbs breadcrumbs">
                        <div class="breadcrumbs-container">
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('payment.breadcrumb_home')); ?></a>
                            <span class="brn_arrow">/</span>
                            <span class="current"><?php echo e(__('payment.breadcrumb_current')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-container show_breadcrumb_v3 no-sidebar">

            


            
            <div id="main-content">
                <div id="primary" class="site-content">
                    <article id="post-12295" class="post-12295 page type-page status-publish hentry">

                        <p><?php echo e(__('payment.section1.title')); ?></p>

                        <p>
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('payment.company_url')); ?></a>
                            <?php echo e(__('payment.section1.text1')); ?><br>
                            <?php echo e(__('payment.section1.text2')); ?>

                        </p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('payment.section2.title')); ?></h2>

                        <p>
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('payment.company_url')); ?></a>
                            <?php echo e(__('payment.section2.text1')); ?><br>
                            <?php echo e(__('payment.section2.text2')); ?>

                        </p>

                        <p>
                            <?php echo e(__('payment.section2.text3')); ?> <strong>S</strong> <?php echo e(__('payment.section2.text4')); ?><br>
                            <a href="<?php echo e(route('home')); ?>"><?php echo e(route('home')); ?></a>
                        </p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('payment.section3.title')); ?></h2>

                        <p><em><?php echo e(__('payment.section3.subtitle')); ?></em></p>

                        <hr class="wp-block-separator has-alpha-channel-opacity">

                        <h2 class="wp-block-heading"><?php echo e(__('payment.section4.title')); ?></h2>

                        <p>
                            <?php echo e(__('payment.section4.text1')); ?> <strong><?php echo e(__('payment.company_name')); ?></strong>
                            <?php echo e(__('payment.section4.text2')); ?>

                        </p>

                        <p><?php echo e(__('payment.section4.text3')); ?></p>

                        <figure class="wp-block-image size-full is-resized">
                            <img fetchpriority="high" decoding="async"
                                 width="512" height="512"
                                 src="/assets/uploads/2026/02/cropped-Porto-Contentores-scaled-1.png"
                                 alt="" class="wp-image-12724"
                                 style="width:413px;height:auto"
                                 sizes="(max-width: 512px) 100vw, 512px">
                        </figure>
                    </article>
                </div>
            </div>

            

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/portaboxPt/resources/views/front/legal/payment-policy.blade.php ENDPATH**/ ?>